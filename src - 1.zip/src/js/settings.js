var settings= angular.module('settings', []);

var bkg = chrome.extension.getBackgroundPage();
