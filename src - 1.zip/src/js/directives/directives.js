//implement focus to quit directive
app.directive('focus', function($document,$window){
	return {
		restrict: 'E',
		template: null,
		replace:
	}
});
